package Model;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;




public class Inventory {

    /** Constructor for allParts, Constructor defines all available parts and their attributes.*/

    private  static final ObservableList<Part>allParts = FXCollections.observableArrayList(new OutSourced(1,"Brakes",12.99
            ,15,1,20,"ABC"), new OutSourced(2,"Tire",14.99,15,1,20,"BBA"),new InHouse(3,"Rim",56.99,15,1,20,100));

    /**Constructor for GiantBicycle parts. Defines all associated parts for Giant Bicycle */
    private static ObservableList<Part>GiantParts = FXCollections.observableArrayList(
            lookupPart(1),
            lookupPart(2)
    );



    /**Constructor for Scott Bicycle parts. Defines all associated parts for Scott Bicycle */
    private static ObservableList<Part>ScottParts = FXCollections.observableArrayList(lookupPart(2));


    /**Constructor for GT Bicycle parts. Defines all associated parts for GT Bicycle.*/
    private static ObservableList<Part>GTParts = FXCollections.observableArrayList(lookupPart(3));


    /** Constructor for allProducts . Constructor defines all available products using the associated parts.*/
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList(new Product(1,"Giant Bicycle",299.99,15,
    1,20,GiantParts),new Product(2,"Scott Bicycle",199.99,15,1,20,ScottParts),new Product(3,"GT Bike",99.99,15,1,20,GTParts));


    /**Return part by PartID, The lookupPart method finds and returns a Part by its PartID.
     * @param partID system generated part UUID
     * @return the Part associated with that PartID or null.
     */
    public static Part lookupPart(int partID) {
        for(Part part : allParts) {
            if(part.getId()==partID){
                return part;
            }
        }
        return null;
    }


    /**Return Product by ProductID. The lookupProduct method finds and returns a product by its productID.
     * @param productID
     * @return
     */

    public static Product lookupProduct(int productID){
        for (Product product: allProducts){
            if (product.getId() == productID){
                return product;
            }
        }
        return null;
    }

    /**Return list of Parts by part name. The lookupPart method finds and returns a Part by its name.
     * @param partName part name.
     * @return the part associated with that part name or null.
     */

  public static ObservableList<Part> lookupPart(String partName){
      ObservableList<Part>filteredPartList = FXCollections.observableArrayList();
        for (Part p :allParts){
            if (partName.compareTo(p.getName()) ==0){
                filteredPartList.add(p);
            }
        }
        return filteredPartList;
  }

    /**Return list Products  by product name. The lookupPart method finds and returns a Product  by its name.
     *
     * @param productName product name
     * @return the Product associated with that product name or null
     */

  public static ObservableList<Product> lookupProduct(String productName){
      ObservableList<Product>filteredProductList = FXCollections.observableArrayList();
      for (Product p : allProducts){
          if (productName.compareTo(p.getName())==0 ){
              filteredProductList.add(p);
          }
      }
      return filteredProductList;
  }

    /** Updates parts at an index, The updatePart method modifies a Part at an index.
     * @param index index position in an array
     * @param selectedPart the updated part instance
     */
  public static void updatePart(int index, Part selectedPart){
      allParts.set(index-1,selectedPart);
  }

    /** Update a product at an index. The updatePart method modifies a Product at an index.
     * @param index index position in an array
     * @param newProduct the updated product instance
     */
  public static void updateProduct (int index,Product newProduct){
      allProducts.set(index-1,newProduct);
  }


    /**Delete a product from allProducts. The deleteProduct method removes a product from the allProducts attribute
     *
     * @param selectedProduct  the product will be deleted
     * @return true if deleted, else false
     */
    public static boolean deleteProduct(Product selectedProduct){
        for (int i = 0;i<allProducts.size();i++){
            if (allProducts.get(i).getId() == selectedProduct.getId()){
                allProducts.remove(i);
                break;
            }
            else {return false;}
        }
        return true;
    }


    /**Delete a part from allParts. The deletePart method removes a part from the allParts attribute
     *
     * @param selectedPart the part will be deleted
     * @return true if deleted, else false
     */

    public static boolean deletePart(Part selectedPart){
        for(int i=0;i< allParts.size();i++){
            if (allParts.get(i).getId() == selectedPart.getId()) {
                allParts.remove(i);
                break;
            }else{
                return false;
            }

            }
        return true;
        }



    /** Add a part to allParts. The addPart method adds a part instance to the allPart list
     *
     * @param newPart user defined Part instance
     */
    public static void addPart (Part newPart){
        if(newPart != null){
            allParts.add(newPart);
        }
    }

    /** /add a product to allProducts. The addProduct method adds a product instance to allProduct list
     * @param productToAdd
     */

    public static void addProduct (Product productToAdd){
        if(productToAdd != null){
            allProducts.add(productToAdd);
        }
    }

    /** Return all products .
     * @return all of the products in the allParts in an ObservableList
     */

    public static ObservableList<Part> getAllParts(){
        return allParts;
    }

    /**Return all products. GetAllProducts is a get method for allProducts attribute.
     * @return
     */
    public static ObservableList<Product>getAllProducts(){
        return allProducts;
    }

}
