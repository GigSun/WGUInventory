package Model;

/** InHouse class extends the abstract Part class, adding " machineID " attribute and defining methods.*/

public class InHouse extends Part {
    private int machineId;
    /** Constructor for InHouse instances.
    @param id system defined
    @param name string name of the product
    @param price , price in USD
    @param stock the amount held in inventory
    @param min min inventory
    @param max maximum inventory
    @param machineId the ID of the machine used to build this part
     */

    public InHouse (int id, String name, double price, int stock,int min, int max,int machineId){
      super( id, name, price, stock,min,max);
      this.machineId = machineId;
    }

    /**  get method for MachID,
    @return  machineId, the ID of the machine used to build this part
     */
    public int getMachineId(){return  machineId;}

    /**Set method for MachID, updates the machine ID for InHouse Parts.
    @param machineId the ID of the machine used to build this part
     */
    public void setMachineId(int machineId) {this.machineId= machineId;}
}
