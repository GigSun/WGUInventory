package Model;


import javafx.collections.ObservableList;


/** The Product class defines methods and attributes for Products.*/

public class Product {
    private ObservableList<Part>associatedParts;
    private int id;
    private String name;
    private double price = 0.0;
    private int stock =0;
    private int min;
    private int max;


    /**Constructor for Product instance
     *
     * @param id define product ID
     * @param name define the name of the product
     * @param price price in USD
     * @param stock the amount held in inventory
     * @param min  minimum inventory
     * @param max maximum inventory
     * @param associatedParts  parts needed to build the product
     */
    public Product(int id ,String name, double price,int stock,int min,int max,ObservableList<Part> associatedParts){
     this.id = id;
     this.name = name;
     this.price = price;
     this.stock = stock;
     this.min = min;
     this.max = max;
     this.associatedParts = associatedParts;
    }


    /**Getter Method for Name. Returns the Product Name for a Product instance.
     @return the name of the product
     */
    public String getName(){return  name;}

    /**Set method for Name , update the name for product instance
     * @param name the name to set
     */
    public void setName(String name) {this.name =name;}

    /**Get method for price , return the price for the product
     * @return price of the product
     */
    public double getPrice(){return price;}

    /**Set method for price  . Update the product Price for the product
     * @param price the price to set
     */
    public void setPrice(double price){this.price = price;}

    /** Get method for stock. Return the inStock quantity for a product instance
     * @return inStock the  quantity of stocked the products
     */
    public int getStock(){return stock;}

    /**Setter method for stock . Updates the products stock levels for a Product instance
     * @param stock the quantity to set.
     */
    public void seStock(int stock){this.stock =stock;}

    /** Getter method for Min. Return the minimum for a product instance
     * @return the min of a product
     */
    public int getMin() {return min;}

    /** Set Method for Min. Update the inventory minimum for a Product instance
     * @param min the min to set
     */
    public void setMin(int min){this.min = min;}

    /**Get Method for Max. Return the minimum for a product instance
     * @return max the max of a product
     */
    public int getMax(){return max;}

    /**Set Method for Max. Update the inventory maximum for a Product instance
     * @param max the max to set
     */
    public void setMax(int max){this.max = max;}

    /**Associated a part with a product. The addAssociatedPart method adds a part to a Product object's associated parts.
     * @param part the part to add
     */
    public void addAssociatedPart(Part part){associatedParts.add(part);}

    /** Get Method for ID. Return the Product ID for a Product instance
     * @return the product ID
     */
    public int getId(){return id;}

    /** Setter method for product ID.
     * @param id the product Id to set
     */
    public void setId(int id) {this.id = id;}



    /**Remove a part association from a product. The removeAssociatedPart method detaches a part from a Product object.
     * @param selectedAssociatedPart part instance to be detached. Type: Part
     * @return true if part is deleted. false if part not deleted
     */
    public boolean deleteAssociatedPart(Part selectedAssociatedPart){
        int id = selectedAssociatedPart.getId();
        int i;
        for (i = 0; i< associatedParts.size();i++){
           if ( associatedParts.get(i).getId()==selectedAssociatedPart.getId()){
               associatedParts.remove(i);
               return true;
           }
        }
        return false;

    }

    /** Returns associated parts for a product. GetAllAssociatedParts method search an array a Product object's associated part
     * @return all associatedParts
     */
    public ObservableList<Part>getAllAssociatedParts(){

                return associatedParts;
            }
}
