package Model;
/**Outsource class extends the abstract Part class, adding "companyName" attribute and defining method.*/

public class OutSourced extends Part{
    private String companyName;

    /** Constructor for OutSourced instances.
     @param id system defined
     @param name string name of the product
     @param price , price in USD
     @param stock the amount held in inventory
     @param min min inventory
     @param max maximum inventory
     @param companyName the name of the firm subcontracted toto build this part
     */

    public OutSourced (int id, String name, double price, int stock,int min, int max,String companyName){
        super( id,name,price,stock,min,max);
        this.companyName = companyName;
    }

    /**  get method for companyName,
    @return  the name of the firm subcontracted to build this part
     */
    public String getCompanyName(){return companyName;}

    /**Set method for companyName, updates the name of firm subcontracted to build  Parts.
    @param companyName name of the firm subcontracted to build the part
     */
    public void setCompanyName (String companyName) {this.companyName = companyName;}
}
