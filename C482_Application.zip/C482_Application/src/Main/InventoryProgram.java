package Main;
import View_Controller.MainScreenController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;


public class InventoryProgram extends Application {

    /** Start load application
     * @param stage  load main screen view
     * @throws IOException failed input
     */
    @Override
    public void start ( Stage stage)throws IOException{
        try {
            FXMLLoader fxmlloader = new FXMLLoader(MainScreenController.class.getResource("MainScreen.fxml"));
            Parent root = fxmlloader.load();
            MainScreenController mainScreen = fxmlloader.getController();
            Scene scene = new Scene((root));
            stage.setTitle("Inventory Management System");
            stage.setScene(scene);
            stage.show();
        }
        catch(IOException e){
            e.printStackTrace();
        }
    }


    /**Main javaFX function call.
     * @param args the command line arguments.
     */

    public static void main(String[] args) {
        launch(args);
    }

}
