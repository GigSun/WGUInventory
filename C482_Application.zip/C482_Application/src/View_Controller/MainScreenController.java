package View_Controller;

import Model.Inventory;
import Model.Part;
import Model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class  MainScreenController  implements Initializable {
    @FXML
    TextField searchPartsBox;
    @FXML
    TextField searchProductsBox;
    @FXML
    TableView<Part>partsTable;
    @FXML
    TableView<Product>productsTable;
    @FXML
    TableColumn<Part,Integer>partIDCol;
    @FXML
    TableColumn<Part,Integer>partPriceCol;
    @FXML
    TableColumn<Part,String>partNameCol;
    @FXML
    TableColumn<Part,Integer>partInventoryCol;
    @FXML
    TableColumn<Product,Integer>productPriceCol;
    @FXML
    TableColumn<Product,Integer>productInventoryCol;
    @FXML
    TableColumn<Product,String>productNameCol;
    @FXML
    TableColumn<Product,Integer>productIDCol;;
    @FXML
    Button addPartsButton;
    @FXML
    Button deletePartsButton;
    @FXML
    Button modifyPartsButton;
    @FXML
    Button addProductsButton;
    @FXML
    Button deleteProductsButton;
    @FXML
    Button modifyProductsButton;
    @FXML
    Button exitButton;


    /** Search function filters the partsTable with parts matching inputted ID or name.*/
    public void searchParts() {
        if (searchPartsBox.getText().trim().isEmpty()){
            partsTable.setItems(Inventory.getAllParts());
        }
        else{
            try{
                Part returnedPart = Inventory.lookupPart(Integer.parseInt(searchPartsBox.getText()));
                if (returnedPart == null)
                {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("No Parts Found");
                    alert.setHeaderText("Please try Again");
                    alert.showAndWait();

                }
                else{
                    ObservableList<Part> filteredPartList = FXCollections.observableArrayList();
                    filteredPartList.add(returnedPart);
                    partsTable.setItems(filteredPartList);
                }
            }

            catch (NumberFormatException e){
                System.out.println("Number format Exception");
                partsTable.setItems(Inventory.lookupPart(searchPartsBox.getText().trim()));

            }
        }
    }


    /**  Display addPart view .
     * @param actionEvent switch to addpart view
     * @throws IOException failed to read the file
     */
    public void addPartsPressed(ActionEvent actionEvent) throws IOException {
       try {
           FXMLLoader loader = new FXMLLoader(getClass().getResource("AddPart.fxml"));
           Parent addPartScreen = loader.load();
           Scene addPartScene = new Scene(addPartScreen);
           Stage winAddPart = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
           winAddPart.setTitle("Add Part");
           winAddPart.setScene(addPartScene);
           winAddPart.show();
       }
       catch (IOException E){
           System.out.println(E.getLocalizedMessage());
       }
    }

    /**Display the modify Part view
     * @param actionEvent switch to modify part view
     * @throws IOException failed to read the file
     */
    public void modifyPartsPressed(ActionEvent actionEvent) throws IOException{
        if (partsTable.getSelectionModel().getSelectedItem() == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No Selection");
            alert.setHeaderText("Please select a part to modify ");
            alert.showAndWait();
        } else {
            Part selectedItem = partsTable.getSelectionModel().getSelectedItem();
           System.out.println(selectedItem.getName());
           ModifyPartController.displayedPart = selectedItem;

           try{

               FXMLLoader loader = new FXMLLoader(getClass().getResource("ModifyPart.fxml"));
               Parent addPartScreen = loader.load();
               Scene addPartScene = new Scene(addPartScreen);
               Stage winAddPart = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
               winAddPart.setTitle("Modify Part");
               winAddPart.setScene(addPartScene);
               winAddPart.show();
           }
           catch (IOException E){
               System.out.println(E.getLocalizedMessage());
           }
           }
        }


    /** Delete a part from the partTable.*/
    public void deletePartsPressed() {
        if (partsTable.getSelectionModel().getSelectedItem() == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No Selection");
            alert.setHeaderText("Please select a part to delete ");
            alert.showAndWait();
        } else {

            Part selectedItem = partsTable.getSelectionModel().getSelectedItem();
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete Part?");
            alert.setHeaderText("press OK to confirm or press Cancel to exit.");
            alert.showAndWait();
            if (alert.getResult() == ButtonType.OK) {
                Inventory.deletePart(selectedItem);
                partsTable.getItems().remove(selectedItem);
            }

            else {alert.close();}
        }
    }


    /** Search function filters the productTable with product matching inputted ID or name.*/
    public void searchProducts(ActionEvent actionEvent) {

        if (searchProductsBox.getText().trim().isEmpty()){
            productsTable.setItems(Inventory.getAllProducts());
        }
        else{
            try{
                Product returnedProduct = Inventory.lookupProduct(Integer.parseInt(searchProductsBox.getText()));
                if (returnedProduct == null)
                {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("No Parts Found");
                    alert.setHeaderText("Please try Again");
                    alert.showAndWait();
                }
                else{
                    ObservableList<Product> filteredProductList = FXCollections.observableArrayList();
                    filteredProductList.add(returnedProduct);
                    productsTable.setItems(filteredProductList);
                }
            }

            catch  (NumberFormatException e){
                System.out.println("Number format Exception");
                productsTable.setItems(Inventory.lookupProduct(searchProductsBox.getText().trim()));
            }
        }
    }

    /** Display add Product view
     * @param actionEvent switch to add product view
     * @throws IOException the failed input
     */

    public void productAddButtonPressed(ActionEvent actionEvent) throws IOException {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AddProduct.fxml"));
            Parent addProductScreen = loader.load();
            Scene addProductScene = new Scene(addProductScreen);
            Stage winAddPart = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
            winAddPart.setTitle("Add Product");
            winAddPart.setScene(addProductScene);
            winAddPart.show();
        }
        catch (IOException E){
            System.out.println(E.getLocalizedMessage());
        }
    }


    /**Display modify product view
     * @param actionEvent to switch to modify product view
     * @throws IOException the failed input
     */
    public void productModifyButtonPressed(ActionEvent actionEvent) throws IOException{
        if (productsTable.getSelectionModel().getSelectedItem() == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No Selection");
            alert.setHeaderText("Please select a product  to modify");
            alert.showAndWait();
        } else {
            Product selectedItem = productsTable.getSelectionModel().getSelectedItem();
            System.out.println(selectedItem.getName());
            ModifyProductController.displayedProduct = selectedItem;

            try{

                FXMLLoader loader = new FXMLLoader(getClass().getResource("ModifyProduct.fxml"));
                Parent addPartScreen = loader.load();
                Scene addPartScene = new Scene(addPartScreen);
                Stage winAddPart = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                winAddPart.setTitle("Modify Product");
                winAddPart.setScene(addPartScene);
                winAddPart.show();
            }
            catch (IOException E){
                System.out.println(E.getLocalizedMessage());
            }
        }
    }


    /** Delete a product  from the product Table.*/
    public void productDeleteButtonPressed() {
        if (productsTable.getSelectionModel().getSelectedItem() == null) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No Selection");
            alert.setHeaderText("Please select a product to Delete ");
            alert.showAndWait();
        } else {
            Product selectedItem = productsTable.getSelectionModel().getSelectedItem();

            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Delete Product?");
            alert.setHeaderText("press OK to confirm or press Cancel to exit.");
            alert.showAndWait();
            if (alert.getResult() == ButtonType.OK) {


            Inventory.deleteProduct(selectedItem);
            partsTable.getItems().remove(selectedItem);}
            else {alert.close();}
        }
    }

    /** Exist Inventory program  if exit button pressed and confirmed .
     * @param actionEvent exit the screen.
     */
    public void exitButtonPressed(ActionEvent actionEvent) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Exit?");
        alert.setHeaderText("Are you sure to exit ?");
        alert.setContentText("Press OK to exit the program, \n Press Cancel to stay on this screen");
        alert.showAndWait();
        if (alert.getResult() == ButtonType.OK){
            Stage winMainScreen = (Stage)((Node) actionEvent.getSource()).getScene().getWindow();
            winMainScreen.close();
        }

        else{
            alert.close();
        }
    }


    /** Laod the partsTable and productTable with column names
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        partIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        partInventoryCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        partPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        updateParts();


        productIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        productNameCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        productInventoryCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        productPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        updateProducts();
    }

    /** Initialize partsTable with parts.*/
    public void updateProducts() {
        partsTable.setItems(Inventory.getAllParts());
    }

    /** Initialize productsTable with parts.*/
    public  void updateParts() {

        productsTable.setItems(Inventory.getAllProducts());
    }
}
