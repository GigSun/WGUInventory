package View_Controller;


import Model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class ModifyProductController implements Initializable {


        public static Product displayedProduct;
        @FXML
        TextField textID;
        @FXML
        TextField textName;
        @FXML
        TextField textPrice;
        @FXML
        TextField textMax;
        @FXML
        TextField textMin;
        @FXML
        TextField textInv;
        @FXML
        Button addPartButton;
        @FXML
        Button saveButton;
        @FXML
        Button cancelButton;
        @FXML
        Button removeAssociatedPartButton;
        @FXML
        TextField searchPartsBox;
        @FXML
        TableView<Part> allPartsTable;
        @FXML
        TableColumn<Part, Integer> allPartsNameCol;
        @FXML
        TableColumn<Part, Integer> allPartsPartIDCol;
        @FXML
        TableColumn<Part, Integer> allPartsInvCol;
        @FXML
        TableColumn<Part, Integer> allPartsPriceCol;
        @FXML
        TableView<Part> associatedPartsTable;
        @FXML
        TableColumn<Part, Integer> asscPartsNameCol;
        @FXML
        TableColumn<Part, Integer> asscPartsPartIDCol;
        @FXML
        TableColumn<Part, Integer> asscPartsPriceCol;
        @FXML
        TableColumn<Part, Integer> asscPartsInvCol;


        /**Save new product and display main screen. The new product is added to allProduct
         * @param actionEvent event to display main screen
         * @throws IOException           throws exception
         * @throws NumberFormatException the input string is invalid
         */
        public void saveButtonPressed(ActionEvent actionEvent) throws IOException, NumberFormatException {


                if (textName.getText().isEmpty()
                        || textInv.getText().isEmpty()
                        || textMin.getText().isEmpty()
                        || textMax.getText().isEmpty()
                        || textPrice.getText().isEmpty()) {
                        System.out.println("Data Empty");
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("Data Error");
                        alert.setHeaderText("Please enter valid data for every field");
                        alert.showAndWait();
                } else if (Integer.parseInt(textMin.getText()) > Integer.parseInt(textMax.getText())) {
                        System.out.println("Min Max Error");
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setHeaderText("Min cannot be greater than Max");
                        alert.setTitle("Max and Min error");
                        alert.show();

                } else if (Integer.parseInt(textMin.getText()) > Integer.parseInt(textInv.getText()) || Integer.parseInt(textInv.getText()) > Integer.parseInt(textMax.getText())) {

                        System.out.println("Inventory Error");
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("Inventory Error");
                        alert.setHeaderText("Inventory should be between the min and max");
                        alert.showAndWait();

                } else {

                        try {

                                int index = displayedProduct.getId();
                                String name = textName.getText();
                                int inventory = Integer.parseInt(textInv.getText());
                                double price = Double.parseDouble(textPrice.getText());
                                int max = Integer.parseInt(textMax.getText());
                                int min = Integer.parseInt(textMin.getText());


                                Product newProduct = new Product(index,name,price,inventory,min,max,associatedPartsTable.getItems());
                                System.out.println(newProduct);
                                Inventory.updateProduct(index,newProduct);
                                FXMLLoader loader = new FXMLLoader(getClass().getResource("MainScreen.fxml"));
                                Parent addPartScreen = loader.load();
                                Scene addPartScene = new Scene(addPartScreen);
                                Stage winAddPart = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                                winAddPart.setScene(addPartScene);
                                winAddPart.setTitle("Main Screen");
                                winAddPart.show();

                        } catch (IOException E) {
                                Alert alert = new Alert(Alert.AlertType.ERROR);
                                alert.setTitle("Type Error");
                                alert.setHeaderText(E.getLocalizedMessage());
                                alert.showAndWait();
                        } catch (NumberFormatException E) {
                                Alert alert = new Alert(Alert.AlertType.ERROR);
                                alert.setTitle("Type Error");
                                alert.setHeaderText("Please format your inputs properly");
                                alert.showAndWait();
                        }
                }
        }


        /**Dispaly MainScreen and does not save user changes. The modified Product instance is abandoned
         * throws IOException failed to read the file
         * @param actionEvent action to display mainscreen
         */
        public void cancelButtonPressed(ActionEvent actionEvent) throws IOException {

                try {
                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                        alert.setHeaderText("Are you sure to exit?");
                        alert.setTitle("Cancel?");
                        alert.setContentText("Press OK to exit the program. \nPress Cancel to stay on this screen");
                        alert.showAndWait();
                        if (alert.getResult() == ButtonType.OK) {

                                FXMLLoader loader = new FXMLLoader(getClass().getResource("MainScreen.fxml"));
                                Parent addPartScreen = loader.load();
                                Scene addPartScene = new Scene(addPartScreen);
                                Stage winAddPart = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                                winAddPart.setTitle("Add Part");
                                winAddPart.setScene(addPartScene);
                                winAddPart.show();
                        } else {
                                alert.close();
                        }
                } catch (IOException E) {
                        System.out.println(E.getLocalizedMessage());
                }

        }


        /**add the selected part in allPartsTable to associatedPartsTable. Display an error if nothing selected.*/
        public void addButtonPressed() {
                if (allPartsTable.getSelectionModel().getSelectedItem() == null) {
                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("No Selection");
                        alert.setHeaderText("Please select a part to add");
                        alert.showAndWait();
                } else {
                        Part selectedItem = allPartsTable.getSelectionModel().getSelectedItem();
                        associatedPartsTable.getItems().add(selectedItem);
                }
        }

        /**Delete part when the associated part is selected.
         *Pop an warning message when try to delete a product associated with only  1 part*/
        public void removeAssociatedPartButtonPressed() {

                if(displayedProduct.getAllAssociatedParts().size() > 1) {
                        Part selectedItem = associatedPartsTable.getSelectionModel().getSelectedItem();
                        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                        alert.setTitle("Delete Product?");
                        alert.setHeaderText("press OK to confirm or press Cancel to exit.");
                        alert.showAndWait();
                        if (alert.getResult() == ButtonType.OK) {

                                associatedPartsTable.getItems().remove(selectedItem);

                        } else {
                                alert.close();
                        }
                }

                else {
                        Alert alert = new Alert(Alert.AlertType.WARNING);
                        alert.setTitle("Part can not been deleted");
                        alert.setHeaderText("You can not delete a product with only 1 part associated.");
                        alert.showAndWait();
                }
        }


        /**Search function filters the allpartsTable with parts matching inputted ID or name.*/
        public void searchParts() {
                if (searchPartsBox.getText().trim().isEmpty()) {
                        allPartsTable.setItems(Inventory.getAllParts());
                } else {
                        try {
                                Part returnedPart = Inventory.lookupPart(Integer.parseInt(searchPartsBox.getText()));
                                if (returnedPart == null) {
                                        Alert alert = new Alert(Alert.AlertType.ERROR);
                                        alert.setTitle("No Parts Found");
                                        alert.setHeaderText("Please try Again");
                                        alert.showAndWait();

                                } else {
                                        ObservableList<Part> filteredPartList = FXCollections.observableArrayList();
                                        filteredPartList.add(returnedPart);
                                        allPartsTable.setItems(filteredPartList);
                                }
                        } catch (NumberFormatException e) {
                                System.out.println("Number format Exception");
                                allPartsTable.setItems(Inventory.lookupPart(searchPartsBox.getText().trim()));

                        }
                }


        }


        /**Load all parts for allParts table.*/
        @FXML
        public void updateAllPartsTable() {
                allPartsTable.setItems(Inventory.getAllParts());

        }

        /**Load all parts for allParts table.*/
        @FXML
        public void updateAssociatedPartsTable() {
                associatedPartsTable.setItems(displayedProduct.getAllAssociatedParts());

        }

        /**Load the allPartsTable and asscPartsTable  .
         * @param url
         * @param resourceBundle
         */

        @Override
        public void initialize(URL url, ResourceBundle resourceBundle) {

                allPartsPartIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
                allPartsInvCol.setCellValueFactory(new PropertyValueFactory<>("name"));
                allPartsNameCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
                allPartsPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
                updateAllPartsTable();

                textID.setText(String.valueOf(displayedProduct.getId()));
                textName.setText(displayedProduct.getName());
                textInv.setText(String.valueOf(displayedProduct.getStock()));
                textPrice.setText(String.valueOf(displayedProduct.getPrice()));
                textMax.setText(String.valueOf(displayedProduct.getMax()));
                textMin.setText(String.valueOf(displayedProduct.getMin()));

                asscPartsPartIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
                asscPartsPartIDCol.setCellValueFactory(new PropertyValueFactory<>("name"));
                asscPartsNameCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
                asscPartsPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
                updateAssociatedPartsTable();

        }
}



