package View_Controller;

import Model.InHouse;
import Model.Inventory;
import Model.OutSourced;
import Model.Part;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;




public class ModifyPartController  implements Initializable {
    public static Part displayedPart;
    @FXML
    RadioButton inHouseRadio;
    @FXML
    RadioButton outSourcedRadio;
    @FXML
    TextField textID;
    @FXML
    TextField textName;
    @FXML
    TextField textInv;
    @FXML
    TextField textPrice;
    @FXML
    TextField textMax;
    @FXML
    TextField textMin;
    @FXML
    TextField textDual;
    @FXML
    Label  dualLabel;
    @FXML
    Button saveButton;
    @FXML
    Button cancelButton;

    /**Updates the UI based on the Radio buttons Builds the ToggleGroup for RadioButton and cahnges the dualLabel based on the selection.*/

    public void setupView(){
    ToggleGroup Tgroup = new ToggleGroup();
    inHouseRadio.setToggleGroup(Tgroup);
    outSourcedRadio.setToggleGroup(Tgroup);
    textID.setText(String.valueOf(displayedPart.getId()));
    textName.setText(displayedPart.getName());
    textInv.setText(String.valueOf(displayedPart.getStock()));
    textPrice.setText(String.valueOf(displayedPart.getPrice()));
    textMin.setText(String.valueOf(displayedPart.getMin()));
    textMax.setText(String.valueOf(displayedPart.getMax()));



    if (displayedPart instanceof InHouse){
        inHouseRadio.setSelected(true);
        dualLabel.setText("Machine ID");
        textDual.setText(Integer.toString(((InHouse) displayedPart).getMachineId()));
    }
    else if (displayedPart instanceof OutSourced) {
        outSourcedRadio.setSelected(true);
        dualLabel.setText("Company Name");
        textDual.setText(((OutSourced) displayedPart).getCompanyName());
    }

}


    /**Initialize the screen.
     * @param url
     * @param resourceBundle
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
    setupView();
    }

    /**Save modified part and display MainScreen. The old part is replaced by new part at the index .
     * @param actionEvent  help to scene transition
     * @throws IOException failed input
     * @throws NumberFormatException  inputted a string in a field designed for integers.
     */

    public void saveButtonPressed(ActionEvent actionEvent)  throws IOException, NumberFormatException{

         if (Integer.parseInt(textMin.getText() )> Integer.parseInt(textMax.getText())) {
            System.out.println("Min Max Error");
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setHeaderText("Min cannot be greater than Max");
            alert.setTitle("Max and Min error");
            alert.show();
        }

        else if (Integer.parseInt(textMin.getText()) > Integer.parseInt(textInv.getText()) || Integer.parseInt(textInv.getText())>Integer.parseInt(textMax.getText())) {

            System.out.println("Inventory Error");
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Inventory Error");
            alert.setHeaderText("Inventory should be between the min and max");
            alert.showAndWait();
        }

        else {

            try {

                int index  = displayedPart.getId();
                String name = textName.getText();
                int inventory = Integer.parseInt(textInv.getText());
                double price = Double.parseDouble(textPrice.getText());
                int max = Integer.parseInt(textMax.getText());
                int min = Integer.parseInt(textMin.getText());
                String dualText = textDual.getText();


                if(inHouseRadio.isSelected()){
                   InHouse inHousePart = new InHouse(index,name,price,inventory,min,max,Integer.parseInt(dualText));
                   Inventory.updatePart(index,inHousePart);

                   FXMLLoader loader = new FXMLLoader(getClass().getResource("MainScreen.fxml"));
                   Parent addPartScreen = loader.load();
                   Scene addPartScene  = new Scene(addPartScreen);


                   Stage winAddPart = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                   winAddPart.setTitle("Add Part");
                   winAddPart.setScene(addPartScene);
                   winAddPart.show();
               }

                else if (outSourcedRadio.isSelected()) {
                   OutSourced outSourcedPart = new OutSourced(index,name,price,inventory,min,max,dualText);
                   Inventory.updatePart(index,outSourcedPart);

                   FXMLLoader loader = new FXMLLoader(getClass().getResource("MainScreen.fxml"));
                   Parent addPartScreen = loader.load();
                   Scene addPartScene  = new Scene(addPartScreen);
                   Stage winAddPart = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                   winAddPart.setTitle("Add part");
                   winAddPart.setScene(addPartScene);
                   winAddPart.show();
                }
            }

            catch (IOException E) {
               System.out.println(E.getLocalizedMessage());
            }

            catch(NumberFormatException E){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Type Error");
                alert.setHeaderText("Pleaes format your inputs like the following :" + "\nName: String" + "\n Price : Double (0.00)"+ "\nMax,Max,Inventory : Integer"+"\nMachin ID : number"+"\nCompany Name: String");
                alert.showAndWait();
            }
        }
    }

    /**Dispaly MainScreen and does not save user changes. The new part instance is abandoned
     * throws IOException failed to read the file
     * @param actionEvent  action to display mainscreen
     */
    public void cancelButtonPressed(ActionEvent actionEvent) throws IOException {

        try{
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setHeaderText("Are you sure to exit?");
            alert.setTitle("Cancel?");
            alert.setContentText("Press OK to exit the program. \nPress Cancel to stay on this screen");
            alert.showAndWait();

            if(alert.getResult()== ButtonType.OK) {
                FXMLLoader loader = new FXMLLoader(getClass().getResource("MainScreen.fxml"));
                Parent addPartScreen = loader.load();
                Scene addPartScene = new Scene(addPartScreen);
                Stage winAddPart = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                winAddPart.setTitle("Add Part");
                winAddPart.setScene(addPartScene);
                winAddPart.show();
            }

            else{
                alert.close();
            }
        }
        catch (IOException E){
            System.out.println(E.getLocalizedMessage());
        }

    }


    /** Updates the UI of based on the Radio Button.
     change dualLabel based on the selection.
     */

    public void updateRadioUI() {
        if (inHouseRadio.isSelected()) {
            dualLabel.setText("Machine ID");

        }
        else if (outSourcedRadio.isSelected()){
            dualLabel.setText("Company Name");
        }
    }
}
