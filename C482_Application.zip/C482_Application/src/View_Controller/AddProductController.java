package View_Controller;

import Model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import javax.management.InvalidAttributeValueException;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class AddProductController implements Initializable {

    @FXML
    TextField textID;

    @FXML
    TextField textName;

    @FXML
    TextField textPrice;

    @FXML
    TextField textMax;

    @FXML
    TextField textMin;

    @FXML
    TextField textInv;

    @FXML
    Button addButton;

    @FXML
    Button saveButton;

    @FXML
    Button cancelButton;

    @FXML
    Button removeAssociatedPartButton;

    @FXML
    TextField searchPartsBox;

    @FXML
    TableView<Part> allPartsTable;


    @FXML
    TableColumn<Part, Integer> allPartsNameCol;

    @FXML
    TableColumn<Part, Integer> allPartsIDCol;

    @FXML
    TableColumn<Part, Integer> allPartsInvCol;

    @FXML
    TableColumn<Part, Integer> allPartsPriceCol;




    @FXML
    TableView<Part> associatedPartsTable;

    @FXML
    TableColumn<Part, Integer> asscPartsNameCol;

    @FXML
    TableColumn<Part, Integer> asscPartsPartIDCol;

    @FXML
    TableColumn<Part, Integer> asscPartsPriceCol;

    @FXML
    TableColumn<Part, Integer> asscPartsInvCol;




    /** Search function filters the allpartsTable with parts matching inputted ID or name.*/
    public void searchParts() {
    if (searchPartsBox.getText().trim().isEmpty()){
        allPartsTable.setItems(Inventory.getAllParts());
    }
    else{
        try{
            Part returnedPart = Inventory.lookupPart(Integer.parseInt(searchPartsBox.getText()));
            if (returnedPart == null)
            {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("No Parts Found");
                alert.setHeaderText("Please try Again");
                alert.showAndWait();

            }
            else{
                ObservableList<Part> filteredPartList = FXCollections.observableArrayList();
                filteredPartList.add(returnedPart);
                allPartsTable.setItems(filteredPartList);
            }
        }

        catch (NumberFormatException e){
            System.out.println("Number format Exception");
            allPartsTable.setItems(Inventory.lookupPart(searchPartsBox.getText().trim()));

        }
    }


    }

    /** add the selected part in allPartsTable to associatedPartsTable. Display an error if nothing selected.
     *
     */
    public void addPartButtonPressed() {
        if(allPartsTable.getSelectionModel().getSelectedItem() == null){
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("No Selection");
            alert.setHeaderText("Please select a part to add");
            alert.showAndWait();
        }
        else{
            Part selectedItem = allPartsTable.getSelectionModel().getSelectedItem();
            associatedPartsTable.getItems().add(selectedItem);
        }
    }

    /** Delete part when the associated part is selected. */
    public void removeAssociatedPressed() {
        Part selectedItem = associatedPartsTable.getSelectionModel().getSelectedItem();
        associatedPartsTable.getItems().remove(selectedItem);
    }


    /**Save new product and display main screen. The new product is added to allProduct
     *
     * @param actionEvent event to display main screen
     * @throws IOException throws exception
     * @throws NumberFormatException the input string is invalid
     */
    public void saveButtonPressed(ActionEvent actionEvent) throws IOException , NumberFormatException{



            if(textName.getText().isEmpty()
                    || textInv.getText().isEmpty()
                    || textMin.getText().isEmpty()
                    || textMax.getText().isEmpty()
                    || textPrice.getText().isEmpty()){
                System.out.println("Data Empty");
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Data Error");
                alert.setHeaderText("Please enter valid data for every field");
                alert.showAndWait();
            }


            else if (Integer.parseInt(textMin.getText() )> Integer.parseInt(textMax.getText())) {
                System.out.println("Min Max Error");
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setHeaderText("Min cannot be greater than Max");
                alert.setTitle("Max and Min error");
                alert.show();

            }


            else if (Integer.parseInt(textMin.getText()) > Integer.parseInt(textInv.getText()) || Integer.parseInt(textInv.getText())>Integer.parseInt(textMax.getText())) {

                System.out.println("Inventory Error");
                Alert alert = new Alert(Alert.AlertType.WARNING);
                alert.setTitle("Inventory Error");
                alert.setHeaderText("Inventory should be between the min and max");
                alert.showAndWait();

            }



            else {

                try {

                    int id = Integer.parseInt(textID.getText());
                    String name = textName.getText();
                    int inventory = Integer.parseInt(textInv.getText());
                    double price = Double.parseDouble(textPrice.getText());
                    int max = Integer.parseInt(textMax.getText());
                    int min = Integer.parseInt(textMin.getText());



                    Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                    alert.setHeaderText("Would you like to save this part?");
                    alert.setTitle("Add Part");
                    alert.showAndWait();

                    if (alert.getResult() == ButtonType.OK) {
                        Product newProduct = new Product(id, name, price,inventory,min, max, associatedPartsTable.getItems());

                        System.out.println(newProduct);
                        Inventory.addProduct(newProduct);

                        FXMLLoader loader = new FXMLLoader(getClass().getResource("MainScreen.fxml"));
                        Parent root = loader.load();
                        Scene scene = new Scene(root);

                        Stage mainScreen = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();
                        mainScreen.setScene(scene);
                        mainScreen.show();
                    } else {
                        alert.close();
                    }
                }


                catch (IOException E) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Type Error");
                    alert.setHeaderText(E.getLocalizedMessage());
                    alert.showAndWait();
                }

                catch(NumberFormatException E){
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Type Error");
                    alert.setHeaderText("Please format your inputs properly");
                    alert.showAndWait();
                }
            }



        }





    /**Displays MainSceen and does not save new Product.
     * @ throws IOException failed to read the file
     * @param actionEvent  display main screen
     */
    public void cancelButtonPressed(ActionEvent actionEvent) throws IOException {

        try{
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setHeaderText("Are you sure to exit?");
            alert.setTitle("Cancel?");
            alert.setContentText("Press OK to exit the program. \nPress Cancel to stay on this screen");
            alert.showAndWait();
            if(alert.getResult()== ButtonType.OK) {

                FXMLLoader loader = new FXMLLoader(getClass().getResource("MainScreen.fxml"));
                Parent addPartScreen = loader.load();
                Scene addPartScene = new Scene(addPartScreen);
                Stage winAddPart = (Stage) ((Node) actionEvent.getSource()).getScene().getWindow();

                winAddPart.setTitle("Add Part");
                winAddPart.setScene(addPartScene);
                winAddPart.show();
            }

            else{
                alert.close();
            }
        }
        catch (IOException E){
            System.out.println(E.getLocalizedMessage());
        }



    }


    /**Load all parts for allParts table.*/
    @FXML
    public void updateAllPartsTable(){
        allPartsTable.setItems(Inventory.getAllParts());

    }

    /**Load the allPartsTable and asscPartsTable  .
     *
     * @param url
     * @param resourceBundle
     */

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        allPartsIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        allPartsInvCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        allPartsNameCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        allPartsPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        updateAllPartsTable();

        asscPartsPartIDCol.setCellValueFactory(new PropertyValueFactory<>("id"));
        asscPartsPartIDCol.setCellValueFactory(new PropertyValueFactory<>("name"));
        asscPartsNameCol.setCellValueFactory(new PropertyValueFactory<>("stock"));
        asscPartsPriceCol.setCellValueFactory(new PropertyValueFactory<>("price"));


        Product lastProduct = Inventory.getAllProducts().get(Inventory.getAllProducts().size()-1);
                int lastID = lastProduct.getId();
        textID.setText(String.valueOf(++lastID));

    }
}
